/**
 *
 * @author 
 *
 */
class UIManager {
	public constructor() {
	}
}
