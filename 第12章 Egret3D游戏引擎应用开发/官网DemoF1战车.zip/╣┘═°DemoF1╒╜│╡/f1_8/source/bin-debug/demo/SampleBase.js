var SampleBase = (function (_super) {
    __extends(SampleBase, _super);
    function SampleBase() {
        _super.call(this);
        this._removeID = -1;
        this._resizeTime = -1;
        this.rect = new eui.Rect();
        this.rect.fillColor = 0xff0000;
        this.rect.fillAlpha = 0.0;
        this.addChild(this.rect);
    }
    var d = __define,c=SampleBase,p=c.prototype;
    p.resize = function () {
        var _this = this;
        if (this._resizeTime == -1) {
            this._resizeTime = setTimeout(function () { return _this.setResize(); }, 300);
        }
    };
    p.onResize = function (x, y, width, height) {
        this.rect.x = x;
        this.rect.y = y;
        this.rect.width = width;
        this.rect.height = height - 88;
    };
    p.setResize = function () {
        clearTimeout(this._resizeTime);
        this._resizeTime = -1;
        this.onResize(0, 0, document.body.clientWidth, document.body.clientHeight);
    };
    return SampleBase;
})(eui.Component);
egret.registerClass(SampleBase,'SampleBase');
