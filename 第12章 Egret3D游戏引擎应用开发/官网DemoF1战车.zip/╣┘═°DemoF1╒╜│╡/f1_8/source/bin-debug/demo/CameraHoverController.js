var Finger = (function () {
    function Finger() {
        this.touchID = -1;
        this.mouseX = 0;
        this.mouseY = 0;
        this.mouseOffsetX = 0;
        this.mouseOffsetY = 0;
        this.mouseLastX = 0;
        this.mouseLastY = 0;
    }
    var d = __define,c=Finger,p=c.prototype;
    return Finger;
})();
egret.registerClass(Finger,'Finger');
/**
 *
 * @author
 *
 */
var CameraHoverController = (function (_super) {
    __extends(CameraHoverController, _super);
    function CameraHoverController(targetObject, lookAtObject, panAngle, tiltAngle, distance, minTiltAngle, maxTiltAngle, minPanAngle, maxPanAngle, steps, yFactor, wrapPanAngle) {
        var _this = this;
        if (targetObject === void 0) { targetObject = null; }
        if (lookAtObject === void 0) { lookAtObject = null; }
        if (panAngle === void 0) { panAngle = 0; }
        if (tiltAngle === void 0) { tiltAngle = 90; }
        if (distance === void 0) { distance = 100; }
        if (minTiltAngle === void 0) { minTiltAngle = -90; }
        if (maxTiltAngle === void 0) { maxTiltAngle = 90; }
        if (minPanAngle === void 0) { minPanAngle = NaN; }
        if (maxPanAngle === void 0) { maxPanAngle = NaN; }
        if (steps === void 0) { steps = 8; }
        if (yFactor === void 0) { yFactor = 2; }
        if (wrapPanAngle === void 0) { wrapPanAngle = false; }
        _super.call(this, targetObject, lookAtObject);
        this._currentPanAngle = 0;
        this._currentTiltAngle = 90;
        this._panAngle = 0;
        this._tiltAngle = 90;
        this._distance = 1000;
        this._minPanAngle = -Infinity;
        this._maxPanAngle = Infinity;
        this._minTiltAngle = -90;
        this._maxTiltAngle = 90;
        this._maxDistance = 5000;
        this._minDistance = -5000;
        this._steps = 8;
        this._yFactor = 2;
        this._wrapPanAngle = false;
        this._lookAtPosition = new egret3d.Vector3D(0.0, 0.0, 0.0);
        this._mouseDown = false;
        this._mouseRightDown = false;
        this._keyArray = new Array();
        this.mouseX = 0;
        this.mouseY = 0;
        this.wheelDelta = 0;
        this.mouseOffsetX = 0;
        this.mouseOffsetY = 0;
        this.mouseLastX = 0;
        this.mouseLastY = 0;
        this._oldPosition1 = null;
        this._oldPosition2 = null;
        this.a = new Finger();
        this.b = new Finger();
        this.distance = distance;
        this.panAngle = panAngle;
        this.tiltAngle = tiltAngle;
        this.minPanAngle = minPanAngle || -Infinity;
        this.maxPanAngle = maxPanAngle || Infinity;
        this.minTiltAngle = minTiltAngle;
        this.maxTiltAngle = maxTiltAngle;
        this.steps = steps;
        this.yFactor = yFactor;
        this.wrapPanAngle = wrapPanAngle;
        //values passed in contrustor are applied immediately
        this._currentPanAngle = this._panAngle;
        this._currentTiltAngle = this._tiltAngle;
        egret3d.Input.instance.addListenerMouseMove(function () { return _this.pcmouseMove(); });
        egret3d.Input.instance.addListenerKeyUp(function (e) { return _this.keyUp(e); });
        egret3d.Input.instance.addListenerKeyDown(function (e) { return _this.keyDown(e); });
        egret3d.Input.instance.addListenerMouseWheel(function () { return _this.pcmouseWheel(); });
    }
    var d = __define,c=CameraHoverController,p=c.prototype;
    p.pcmouseWheel = function () {
        this._distance -= egret3d.Input.instance.wheelDelta * 0.1;
        this._distance = Math.max(this._minDistance, Math.min(this._maxDistance, this._distance));
    };
    p.pcmouseMove = function () {
        if (this._mouseDown) {
            this._tiltAngle += egret3d.Input.instance.mouseOffsetY * 0.1;
            this._tiltAngle = Math.max(this._minTiltAngle, Math.min(this._maxTiltAngle, this._tiltAngle));
            this._panAngle += egret3d.Input.instance.mouseOffsetX * 0.1;
            this._panAngle = Math.max(this._minPanAngle, Math.min(this._maxPanAngle, this._panAngle));
        }
    };
    p.useEventDis = function (e) {
        e.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchStart, this);
        e.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchMove, this);
        e.addEventListener(egret.TouchEvent.TOUCH_END, this.touchEnd, this);
    };
    p.touchStart = function (e) {
        //            egret3d.Debug.instance.trace("touchStart");
        if (this.a.touchID == -1) {
            this.a.touchID = e.touchPointID;
            this.a.mouseX = e.stageX;
            this.a.mouseY = e.stageY;
        }
        else if (this.b.touchID == -1) {
            this.b.touchID = e.touchPointID;
            this.b.mouseX = e.stageX;
            this.b.mouseY = e.stageY;
        }
        this._mouseDown = true;
    };
    p.touchEnd = function (e) {
        //            egret3d.Debug.instance.trace("touchEnd");
        if (this.a.touchID == e.touchPointID) {
            this.a.touchID = -1;
            this.a.mouseX = e.stageX;
            this.a.mouseY = e.stageY;
        }
        else if (this.b.touchID == e.touchPointID) {
            this.b.touchID = -1;
            this.b.mouseX = e.stageX;
            this.b.mouseY = e.stageY;
        }
        this._mouseDown = false;
    };
    p.touchMove = function (e) {
        // egret3d.Debug.instance.trace(e.touchPointID.toString());
        if (this.a.touchID == e.touchPointID) {
            this.a.mouseLastX = this.a.mouseX;
            this.a.mouseLastY = this.a.mouseY;
            this.mouseOffsetX = this.a.mouseOffsetX = e.stageX - this.a.mouseLastX;
            this.mouseOffsetY = this.a.mouseOffsetY = e.stageY - this.a.mouseLastY;
            this.a.mouseX = e.stageX;
            this.a.mouseY = e.stageY;
        }
        else if (this.b.touchID == e.touchPointID) {
            this.b.mouseLastX = this.b.mouseX;
            this.b.mouseLastY = this.b.mouseY;
            this.b.mouseOffsetX = this.mouseOffsetX = e.stageX - this.b.mouseLastX;
            this.b.mouseOffsetY = this.mouseOffsetY = e.stageY - this.b.mouseLastY;
            this.b.mouseX = e.stageX;
            this.b.mouseY = e.stageY;
        }
        if (this.a.touchID != -1 && this.b.touchID != -1) {
            var newPosition1 = new egret3d.Point(this.a.mouseX, this.a.mouseY);
            var newPosition2 = new egret3d.Point(this.b.mouseX, this.b.mouseY);
            if (this._oldPosition1 == null)
                this._oldPosition1 = newPosition1;
            if (this._oldPosition2 == null)
                this._oldPosition2 = newPosition2;
            var value = this.isEnlarge(this._oldPosition1, this._oldPosition2, newPosition1, newPosition2);
            if (value == 1)
                this.wheelDelta = 80;
            else if (value == -1)
                this.wheelDelta = -80;
            this._oldPosition1 = newPosition1;
            this._oldPosition2 = newPosition2;
            this.mouseWheel();
        }
        else {
            this.mouseMove();
        }
    };
    p.isEnlarge = function (op1, op2, np1, np2) {
        //函数传入上一次触摸两点的位置与本次触摸两点的位置计算出用户的手势
        var leng1 = Math.sqrt((op1.x - op2.x) * (op1.x - op2.x) + (op1.y - op2.y) * (op1.y - op2.y));
        var leng2 = Math.sqrt((np1.x - np2.x) * (np1.x - np2.x) + (np1.y - np2.y) * (np1.y - np2.y));
        if (Math.abs(leng1 - leng2) > 2) {
            if (leng1 < leng2) {
                //放大手势
                return 1;
            }
            else {
                //缩小手势
                return -1;
            }
        }
        else {
            return 0;
        }
    };
    p.mouseWheel = function () {
        this._distance -= this.wheelDelta * 0.1;
        this._distance = Math.max(this._minDistance, Math.min(this._maxDistance, this._distance));
    };
    p.keyDown = function (key) {
        switch (key) {
            case egret3d.KeyCode.Key_W:
                this._keyArray[0] = true;
                break;
            case egret3d.KeyCode.Key_A:
                this._keyArray[1] = true;
                break;
            case egret3d.KeyCode.Key_S:
                this._keyArray[2] = true;
                break;
            case egret3d.KeyCode.Key_D:
                this._keyArray[3] = true;
                break;
            case egret3d.KeyCode.Key_Mouse_Left:
                this._mouseDown = true;
                break;
            case egret3d.KeyCode.Key_Mouse_Right:
                this._mouseRightDown = true;
                break;
        }
    };
    p.keyUp = function (key) {
        switch (key) {
            case egret3d.KeyCode.Key_W:
                this._keyArray[0] = false;
                break;
            case egret3d.KeyCode.Key_A:
                this._keyArray[1] = false;
                break;
            case egret3d.KeyCode.Key_S:
                this._keyArray[2] = false;
                break;
            case egret3d.KeyCode.Key_D:
                this._keyArray[3] = false;
                break;
            case egret3d.KeyCode.Key_Mouse_Left:
                this._mouseDown = false;
                break;
            case egret3d.KeyCode.Key_Mouse_Right:
                this._mouseRightDown = false;
                break;
        }
    };
    p.mouseMove = function () {
        if (this._mouseDown) {
            this._tiltAngle += this.mouseOffsetY * 0.1;
            this._tiltAngle = Math.max(this._minTiltAngle, Math.min(this._maxTiltAngle, this._tiltAngle));
            this._panAngle += this.mouseOffsetX * 0.1;
            this._panAngle = Math.max(this._minPanAngle, Math.min(this._maxPanAngle, this._panAngle));
        }
    };
    d(p, "lookAtPosition"
        /**
        * @language zh_CN
        * 返回目标的位置
        *
        * @returns 目标的位置
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._lookAtPosition;
        }
        /**
        * @language zh_CN
        * 设置目标坐标
        *
        * @param val 摄像机看向的目标点
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            this._lookAtPosition = val;
            this.notifyUpdate();
        }
    );
    d(p, "steps"
        /**
        * @private
        */
        ,function () {
            return this._steps;
        }
        /**
        * @private
        */
        ,function (val) {
            val = (val < 1) ? 1 : val;
            if (this._steps == val)
                return;
            this._steps = val;
            this.notifyUpdate();
        }
    );
    d(p, "panAngle"
        /**
        * @language zh_CN
        * 得到相机y轴旋转角度
        * @returns 相机y轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._panAngle;
        }
        /**
        * @language zh_CN
        * 设置相机y轴旋转
        * @param val 旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            val = Math.max(this._minPanAngle, Math.min(this._maxPanAngle, val));
            if (this._panAngle == val)
                return;
            this._panAngle = val;
            this.notifyUpdate();
        }
    );
    d(p, "tiltAngle"
        /**
        * @language zh_CN
        * 得到相机x轴旋转角度
        * @returns 相机x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._tiltAngle;
        }
        /**
        * @language zh_CN
        * 设置相机x轴旋转
        * @param val 旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            val = Math.max(this._minTiltAngle, Math.min(this._maxTiltAngle, val));
            if (this._tiltAngle == val)
                return;
            this._tiltAngle = val;
            this.notifyUpdate();
        }
    );
    d(p, "distance"
        /**
        * @language zh_CN
        * 得到目标和相机的距离
        * @returns 目标和相机的距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._distance;
        }
        /**
        * @language zh_CN
        * 设置目标和相机的距离
        * @param val 距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._distance == val)
                return;
            this._distance = this._distance = Math.max(this._minDistance, Math.min(this._maxDistance, val));
            this.notifyUpdate();
        }
    );
    d(p, "minPanAngle"
        /**
        * @language zh_CN
        * 得到相机最小y轴旋转角度
        * @returns 相机最小x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._minPanAngle;
        }
        /**
        * @language zh_CN
        * 设置相机最小y轴旋转角度
        * @param val 相机最小x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._minPanAngle == val)
                return;
            this._minPanAngle = val;
            this.panAngle = Math.max(this._minPanAngle, Math.min(this._maxPanAngle, this._panAngle));
        }
    );
    d(p, "maxPanAngle"
        /**
        * @language zh_CN
        * 得到相机最大y轴旋转角度
        * @returns 相机最大y轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._maxPanAngle;
        }
        /**
        * @language zh_CN
        * 设置相机最大y轴旋转角度
        * @param val 相机最大y轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._maxPanAngle == val)
                return;
            this._maxPanAngle = val;
            this.panAngle = Math.max(this._minPanAngle, Math.min(this._maxPanAngle, this._panAngle));
        }
    );
    d(p, "minTiltAngle"
        /**
        * @language zh_CN
        * 得到相机最小x轴旋转角度
        * @returns 相机最小x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._minTiltAngle;
        }
        /**
        * @language zh_CN
        * 设置相机最小x轴旋转角度
        * @param val 相机最小x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._minTiltAngle == val)
                return;
            this._minTiltAngle = val;
            this.tiltAngle = Math.max(this._minTiltAngle, Math.min(this._maxTiltAngle, this._tiltAngle));
        }
    );
    d(p, "maxTiltAngle"
        /**
        * @language zh_CN
        * 得到相机最大x轴旋转角度
        * @returns 相机最大x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._maxTiltAngle;
        }
        /**
        * @language zh_CN
        * 设置相机最大x轴旋转角度
        * @param val 相机最大x轴旋转角度
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._maxTiltAngle == val)
                return;
            this._maxTiltAngle = val;
            this.tiltAngle = Math.max(this._minTiltAngle, Math.min(this._maxTiltAngle, this._tiltAngle));
        }
    );
    d(p, "maxDistance"
        /**
        * @language zh_CN
        * 得到相机和目标最大的距离
        * @returns 相机和目标最大的距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._maxDistance;
        }
        /**
        * @language zh_CN
        * 设置相机和目标最大的距离
        * @param val 相机和目标最大的距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._maxDistance == val)
                return;
            this._maxDistance = val;
            this._distance = Math.max(this._minDistance, Math.min(this._maxDistance, this._distance));
        }
    );
    d(p, "minDistance"
        /**
        * @language zh_CN
        * 得到相机和目标最小的距离
        * @returns 相机和目标最小的距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function () {
            return this._maxDistance;
        }
        /**
        * @language zh_CN
        * 设置相机和目标最小的距离
        * @param val 相机和目标最小的距离
        * @version Egret 3.0
        * @platform Web,Native
        */
        ,function (val) {
            if (this._minDistance == val)
                return;
            this._minDistance = val;
            this._distance = Math.max(this._minDistance, Math.min(this._maxDistance, this._distance));
        }
    );
    d(p, "yFactor"
        /**
        * @private
        */
        ,function () {
            return this._yFactor;
        }
        /**
        * @private
        */
        ,function (val) {
            if (this._yFactor == val)
                return;
            this._yFactor = val;
            this.notifyUpdate();
        }
    );
    d(p, "wrapPanAngle"
        /**
        * @private
        */
        ,function () {
            return this._wrapPanAngle;
        }
        /**
        * @private
        */
        ,function (val) {
            if (this._wrapPanAngle == val)
                return;
            this._wrapPanAngle = val;
            this.notifyUpdate();
        }
    );
    /**
    * @language zh_CN
    * 控制器数据更新
    * @param interpolate
    * @version Egret 3.0
    * @platform Web,Native
    */
    p.update = function (interpolate) {
        if (interpolate === void 0) { interpolate = true; }
        if (this._tiltAngle != this._currentTiltAngle || this._panAngle != this._currentPanAngle) {
            this.notifyUpdate();
            if (this._wrapPanAngle) {
                if (this._panAngle < 0)
                    this._panAngle = (this._panAngle % 360) + 360;
                else
                    this._panAngle = this._panAngle % 360;
                if (this._panAngle - this._currentPanAngle < -180)
                    this._currentPanAngle -= 360;
                else if (this._panAngle - this._currentPanAngle > 180)
                    this._currentPanAngle += 360;
            }
            if (interpolate) {
                this._currentTiltAngle += (this._tiltAngle - this._currentTiltAngle) / (this.steps + 1);
                this._currentPanAngle += (this._panAngle - this._currentPanAngle) / (this.steps + 1);
            }
            else {
                this._currentPanAngle = this._panAngle;
                this._currentTiltAngle = this._tiltAngle;
            }
            //snap coords if angle differences are close
            if ((Math.abs(this._tiltAngle - this._currentTiltAngle) < 0.01) && (Math.abs(this._panAngle - this._currentPanAngle) < 0.01)) {
                this._currentTiltAngle = this._tiltAngle;
                this._currentPanAngle = this._panAngle;
            }
        }
        var pos = (this._lookAtObject) ? this._lookAtObject.position : (this._lookAtPosition) ? this._lookAtPosition : this._origin;
        var p = new egret3d.Vector3D();
        p.x = pos.x + this.distance * Math.sin(this._currentPanAngle * egret3d.MathUtil.DEGREES_TO_RADIANS) * Math.cos(this._currentTiltAngle * egret3d.MathUtil.DEGREES_TO_RADIANS);
        p.z = pos.z + this.distance * Math.cos(this._currentPanAngle * egret3d.MathUtil.DEGREES_TO_RADIANS) * Math.cos(this._currentTiltAngle * egret3d.MathUtil.DEGREES_TO_RADIANS);
        p.y = pos.y + this.distance * Math.sin(this._currentTiltAngle * egret3d.MathUtil.DEGREES_TO_RADIANS) * this.yFactor;
        if (this._target) {
            if (this._lookAtPosition)
                this._target.lookAt(p, this._lookAtPosition);
        }
    };
    return CameraHoverController;
})(egret3d.ControllerBase);
egret.registerClass(CameraHoverController,'CameraHoverController');
