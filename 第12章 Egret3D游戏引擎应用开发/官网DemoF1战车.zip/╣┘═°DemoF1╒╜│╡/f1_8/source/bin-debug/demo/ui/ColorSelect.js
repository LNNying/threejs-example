/**
 *
 * @author
 *
 */
var ColorSelect = (function (_super) {
    __extends(ColorSelect, _super);
    function ColorSelect() {
        _super.call(this);
        this.initUI();
    }
    var d = __define,c=ColorSelect,p=c.prototype;
    p.initUI = function () {
        this.skinName = "resource/eui_skins/ColorPickSkin.exml";
    };
    return ColorSelect;
})(eui.Component);
egret.registerClass(ColorSelect,'ColorSelect');
