/**
 *
 * @author
 *
 */
var LoadingPanel = (function (_super) {
    __extends(LoadingPanel, _super);
    function LoadingPanel() {
        _super.call(this);
        this.init();
    }
    var d = __define,c=LoadingPanel,p=c.prototype;
    p.init = function () {
        this.skinName = "resource/eui_skins/LoadingSkin.exml";
    };
    p.setProgress = function (loaded, total) {
        this.pr.text = "loading:" + loaded.toString() + "/" + total.toString();
        this.loadProgress.value = Math.floor(loaded / total);
    };
    return LoadingPanel;
})(eui.Component);
egret.registerClass(LoadingPanel,'LoadingPanel');
