/**
 *
 * @author
 *
 */
var NavPanel = (function (_super) {
    __extends(NavPanel, _super);
    function NavPanel() {
        _super.call(this);
        this.callList = new Object();
        this.initUI();
    }
    var d = __define,c=NavPanel,p=c.prototype;
    p.initUI = function () {
        this.skinName = "resource/eui_skins/NavSkin.exml";
        this.left = 0;
        this.bottom = 0;
        this.right = 0;
        this._colorSelect = new ColorSelect();
        this.colorCroup.addChild(this._colorSelect);
        this._colorSelect.addEventListener(egret.TouchEvent.TOUCH_TAP, this.selectColorHandler, this);
        var partList = this.partGroup.$children;
        for (var i = 0; i < partList.length; i++) {
            partList[i].addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandler, this);
        }
        this._currentSelect = partList[0];
        this._currentSelect.selected = true;
    };
    p.selectColorHandler = function (event) {
        this._currentSelectRect = event.target;
        this._currentSelectColor = this._currentSelectRect.fillColor;
        this.change();
    };
    p.touchHandler = function (event) {
        this._currentSelect = event.target;
        console.log(this._currentSelect.label);
    };
    p.change = function () {
        switch (this._currentSelect.label) {
            case "body":
                this.bodyColor_label.fillColor = this._currentSelectColor;
                this.callList["body"](this._currentSelectColor);
                break;
            case "fender":
                this.fenderColor_label.fillColor = this._currentSelectColor;
                this.callList["fender"](this._currentSelectColor);
                break;
            case "wheelHub":
                this.wheelHubColor_label.fillColor = this._currentSelectColor;
                this.callList["wheelHub"](this._currentSelectColor);
                break;
        }
    };
    p.colorChange = function (label, callBack) {
        this.callList[label] = callBack;
    };
    return NavPanel;
})(eui.Component);
egret.registerClass(NavPanel,'NavPanel');
