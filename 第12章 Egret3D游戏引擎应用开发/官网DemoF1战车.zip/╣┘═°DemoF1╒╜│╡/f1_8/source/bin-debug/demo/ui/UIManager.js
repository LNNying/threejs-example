/**
 *
 * @author
 *
 */
var UIManager = (function () {
    function UIManager() {
    }
    var d = __define,c=UIManager,p=c.prototype;
    return UIManager;
})();
egret.registerClass(UIManager,'UIManager');
