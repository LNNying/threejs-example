		function initMusic()
		{
			//��ʼ����������
        	music=document.createElement("audio");
        	var sourceMusic=document.createElement("source");
        	sourceMusic.src="music/backgroundMusic.ogg";
        	music.loop=true;
        	music.preload=true;
       	 	music.autoplay=false;
        	music.appendChild(sourceMusic);
		    //��ʼ����ײ��Ч
        	crashSound=document.createElement("audio");
        	var sourceMusicCrash=document.createElement("source");
        	sourceMusicCrash.src="music/crash.ogg";
        	crashSound.loop=false;
        	crashSound.preload=true;
        	crashSound.autoplay=false;
        	crashSound.appendChild(sourceMusicCrash);
        	crashSound.onended=crashSound.pause;
		}