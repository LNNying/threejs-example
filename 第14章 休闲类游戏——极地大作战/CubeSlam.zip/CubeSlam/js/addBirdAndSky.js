		function addBird()
		{
			jsonLoader.load( "model/flamingo.js", function( geometry ) {
					geometry.computeVertexNormals();
					geometry.computeMorphNormals();
					var material = new THREE.MeshPhongMaterial( {
						color: 0xffffff,
						morphTargets: true,
						morphNormals: true,
						vertexColors: THREE.FaceColors,
						shading: THREE.SmoothShading
					} );
					var mesh = new THREE.Mesh( geometry, material );
					mesh.position.x = -240;
					mesh.position.y = 50;
					mesh.position.z = 360;
					mesh.rotation.y = Math.PI/8*7;
					mesh.scale.set( 0.15, 0.15, 0.15 );
					bird = mesh;
					bird.station = 1;
					scene.add( mesh );
					mixer = new THREE.AnimationMixer( mesh );
					mixer.clipAction( geometry.animations[ 0 ] ).setDuration( 1 ).play();

				} );
		}
		function initskybox()//创建天空盒
		{

			var textureCube = new THREE.CubeTextureLoader().load(["texture/pos1.jpg", "texture/pos2.jpg", "texture/pos3.jpg", "texture/pos4.jpg", "texture/pos5.jpg", "texture/pos6.jpg"]);
			textureCube.mapping = THREE.CubeRefractionMapping;
			scene.background = textureCube;
		}